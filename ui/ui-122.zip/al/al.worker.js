/* دماج — ضبط النص على الصوت (محاذاة قسرية CTC) في خيط منفصل حتى لا يتجمّد التطبيق.
   يستقبل: init {ort: نص المكتبة, wasm: ArrayBuffer, model: ArrayBuffer}
           run  {id, x: Float32Array 16kHz, tk: Int32Array رموز الحروف (0 = فاصل كلمات), wm: Int32Array رقم الكلمة لكل رمز, free: نهاية حرة}
   يعيد:   prog {id, p} ثم res {id, s, e} (إطار البداية والنهاية لكل كلمة، -1 = لم تُحاذَ) */
'use strict';
let ses = null, inName = 'input_values', LL = null;
const BL = 33, NV = 36, HOP = 320, SR = 16000;
let KEEP = 8 * SR, PAD = Math.round(.8 * SR);   // مقاطع قصيرة: ذاكرة أقل (الطبقة الأولى ≈ ٦٫٥ م.ب لكل ثانية)

async function init(m){
  if (!self.ort) importScripts(URL.createObjectURL(new Blob([m.ort], { type:'text/javascript' })));
  ort.env.wasm.numThreads = 1; ort.env.wasm.proxy = false; ort.env.wasm.simd = true;
  ort.env.wasm.wasmPaths = { 'ort-wasm-simd.wasm':URL.createObjectURL(new Blob([m.wasm], { type:'application/wasm' })) };
  if (m.keep) KEEP = Math.round(m.keep * SR);
  ses = await ort.InferenceSession.create(new Uint8Array(m.model), { executionProviders:['wasm'], graphOptimizationLevel:'all', enableCpuMemArena:false });
  m.model = null;
  inName = ses.inputNames[0] || inName;
}

// احتمالات الحروف لكل ٢٠ مللي ثانية — مقاطع ١٥ ث مع ثانية سياق من كل جهة
async function logits(x, id){
  const N = x.length, T = Math.max(1, Math.floor(N / HOP)), L = new Float32Array(T * NV).fill(-30);
  for (let s = 0; s < N; s += KEEP){
    const w0 = Math.max(0, s - PAD), w1 = Math.min(N, s + KEEP + PAD), n = Math.max(800, w1 - w0), seg = new Float32Array(n);
    seg.set(x.subarray(w0, w1));
    let mu = 0; for (let i = 0; i < n; i++) mu += seg[i]; mu /= n;
    let sd = 0; for (let i = 0; i < n; i++){ const d = seg[i] - mu; sd += d * d; } sd = Math.sqrt(sd / n) + 1e-7;
    for (let i = 0; i < n; i++) seg[i] = (seg[i] - mu) / sd;
    const o = await ses.run({ [inName]:new ort.Tensor('float32', seg, [1, n]) }), out = o[Object.keys(o)[0]], F = out.dims[1], D = out.data;
    const k0 = Math.round((s - w0) / HOP), k1 = Math.min(F, Math.round((Math.min(N, s + KEEP) - w0) / HOP)), t0 = Math.round(s / HOP);
    for (let k = k0; k < k1; k++){
      const t = t0 + k - k0; if (t >= T) break;
      let mx = -1e30; for (let v = 0; v < NV; v++) mx = Math.max(mx, D[k * NV + v]);
      let z = 0; for (let v = 0; v < NV; v++) z += Math.exp(D[k * NV + v] - mx);
      const lz = mx + Math.log(z); for (let v = 0; v < NV; v++) L[t * NV + v] = D[k * NV + v] - lz;
    }
    postMessage({ t:'prog', id, p:Math.min(1, (s + KEEP) / N) });
  }
  return { L, T };
}

// فيتربي على شبكة CTC (فراغ بين كل رمزين)
function viterbi(L, T, tk, wm, nW, free, fs, bn){
  const n = tk.length, S = 2 * n + 1, ext = new Int32Array(S).fill(BL);
  for (let i = 0; i < n; i++) ext[2 * i + 1] = tk[i];
  const NEG = -1e30; let dp = new Float64Array(S).fill(NEG), nx = new Float64Array(S);
  const bp = new Uint8Array(T * S);
  dp[0] = L[ext[0]]; if (S > 1) dp[1] = L[ext[1]];
  if (fs) for (let j = 2; j < S; j++){ const i = j >> 1; if ((j & 1) ? tk[i] === 0 || tk[i - 1] === 0 : tk[i - 1] === 0) dp[j] = L[ext[j]]; }   // بداية حرة: قد يبدأ المقطع بعد أول النص (عند فاصل كلمة)
  for (let t = 1; t < T; t++){
    const r = t * NV, b = t * S;
    for (let s = 0; s < S; s++){
      let best = dp[s], k = 0; const B = s & 1 ? bn : 0;   // bn: مكافأة كل حرف جديد — مع النهاية الحرة لا يتوقف المسار مبكراً
      if (s > 0 && dp[s - 1] + B > best){ best = dp[s - 1] + B; k = 1; }
      if (s > 1 && (s & 1) && ext[s] !== ext[s - 2] && dp[s - 2] + B > best){ best = dp[s - 2] + B; k = 2; }
      nx[s] = best <= NEG ? NEG : best + L[r + ext[s]]; bp[b + s] = k;
    }
    const tmp = dp; dp = nx; nx = tmp;
  }
  let s = S - 1;
  if (S > 1 && dp[S - 2] > dp[S - 1]) s = S - 2;
  if (free) for (let j = 0; j < S; j++) if (dp[j] > dp[s]) s = j;   // التسجيل مقطوع: قد لا يُنطق آخر النص
  if (dp[s] <= NEG) return null;
  const st = new Int32Array(nW).fill(-1), en = new Int32Array(nW).fill(-1);
  for (let t = T - 1; t >= 0; t--){
    if (s & 1){ const w = wm[s >> 1]; if (w >= 0){ st[w] = t; if (en[w] < 0) en[w] = t + 1; } }
    s -= bp[t * S + s];
  }
  return { st, en };
}

onmessage = async e => {
  const m = e.data;
  try {
    if (m.t === 'init'){ await init(m); postMessage({ t:'ok' }); return; }
    // ui-88: «تعرّف على الكلام» — الصوت أولاً: rec يحسب الاحتمالات مرة ويعيد ما سُمع (حروفاً لكل ٢٠ م.ث) ويحفظها،
    // ثم vit يضبط كلمات النص المطابق على الاحتمالات المحفوظة نفسها (بلا حساب ثانٍ)
    if (m.t === 'rec'){
      if (!ses) throw new Error('noinit');
      const { L, T } = await logits(m.x, m.id); LL = { L, T };
      const g = new Int16Array(T); for (let t = 0; t < T; t++){ let bi = 0, bv = -1e30; for (let v = 0; v < NV; v++) if (L[t * NV + v] > bv){ bv = L[t * NV + v]; bi = v; } g[t] = bi; }
      postMessage({ t:'res', id:m.id, g, T }); return;
    }
    if (m.t === 'vit'){
      if (!LL) throw new Error('nolog');
      const r = viterbi(LL.L, LL.T, m.tk, m.wm, m.nW, m.free, m.fs, m.free || m.fs ? (m.bn == null ? 2 : m.bn) : 0);
      if (!r) throw new Error('noalign');
      postMessage({ t:'res', id:m.id, s:r.st, e:r.en, T:LL.T }, [r.st.buffer, r.en.buffer]); return;
    }
    if (m.t === 'setL'){ LL = { L:m.L, T:m.T }; postMessage({ t:'res', id:m.id }); return; }   // APK 19: الاحتمالات من داخل التطبيق
    if (m.t === 'drop'){ LL = null; return; }
    if (m.t === 'run'){
      if (!ses) throw new Error('noinit');
      const { L, T } = await logits(m.x, m.id);
      const r = viterbi(L, T, m.tk, m.wm, m.nW, m.free, m.fs, m.free || m.fs ? (m.bn == null ? 2 : m.bn) : 0);
      if (!r) throw new Error('noalign');
      let g = null; if (m.dbg){ g = new Int16Array(T); for (let t = 0; t < T; t++){ let bi = 0, bv = -1e30; for (let v = 0; v < NV; v++) if (L[t * NV + v] > bv){ bv = L[t * NV + v]; bi = v; } g[t] = bi; } }   // ما سمعه النموذج (للتحقق من مطابقة الصوت للنص)
      postMessage({ t:'res', id:m.id, s:r.st, e:r.en, T, g }, [r.st.buffer, r.en.buffer]);
    }
  } catch (err){ postMessage({ t:'err', id:m.id, e:String(err && err.message || err).slice(0, 120) }); }
};
